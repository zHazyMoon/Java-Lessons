

public class Hamburguer {

    private Double      preco;
    private int         QueijoChedar;
    private String      carne;

    public Double getPreco() {
        return preco;
    }

    public int getQueijoChedar() {
        return QueijoChedar;
    }

    public String getCarne() {
        return carne;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public void setQueijoChedar(int QueijoChedar) {
        this.QueijoChedar = QueijoChedar;
    }

    public void setCarne(String carne) {
        this.carne = carne;
    }
    
}
