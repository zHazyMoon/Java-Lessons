


public interface Animal extends Cloneable{

    public abstract Animal clonar();
    
}
