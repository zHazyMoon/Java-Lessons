
public class NotebookWindowsDell extends NotebookWindows{
    
    public NotebookWindowsDell(){
        setPreco(4500.0);
    }    
    
    @Override
    public String toString() {
        return "WINDWOS Dell";
    }
}
