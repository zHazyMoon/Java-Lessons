
public class NotebookWindowsLenovo extends NotebookWindows{
    
    
    
    @Override
    public String toString() {
        return "WINDWOS ACER";
    }
}
