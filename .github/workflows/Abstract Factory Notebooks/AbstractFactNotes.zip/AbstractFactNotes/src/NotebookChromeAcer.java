
public class NotebookChromeAcer extends NotebookChrome {

    public NotebookChromeAcer() {
    }
    
}
