
public class NotebookLinuxDell extends NotebookLinux{

    
    public NotebookLinuxDell(){
        setPreco(2955.00);
    }
    
    @Override
    public String toString() {
        return "LINUX DELL" + getPreco(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
