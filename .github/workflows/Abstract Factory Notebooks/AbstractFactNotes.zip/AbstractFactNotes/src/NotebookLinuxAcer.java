
public class NotebookLinuxAcer extends NotebookLinux{
    @Override
    public String toString() {
        return "LINUX ACER"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
