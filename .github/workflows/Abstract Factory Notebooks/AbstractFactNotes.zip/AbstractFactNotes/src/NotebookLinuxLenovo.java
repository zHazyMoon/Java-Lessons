
public class NotebookLinuxLenovo extends NotebookLinux{
    
}
