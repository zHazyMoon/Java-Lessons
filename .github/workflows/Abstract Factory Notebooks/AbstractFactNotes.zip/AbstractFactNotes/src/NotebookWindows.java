
public abstract class NotebookWindows {
    
    private Double preco;
    
    private String so;

    public Double getPreco() {
        return preco;
    }

    public String getSo() {
        return so;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public void setSo(String so) {
        this.so = so;
    }
}
