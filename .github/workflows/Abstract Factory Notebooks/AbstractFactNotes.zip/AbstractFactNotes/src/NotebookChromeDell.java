
public class NotebookChromeDell extends NotebookChrome {

    public NotebookChromeDell() {
    }
    
}
