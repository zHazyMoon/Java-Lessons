
public class NotebookWindowsAcer extends NotebookWindows{

    @Override
    public String toString() {
        return "WINDWOS ACER";
    }
    
    
    
}
